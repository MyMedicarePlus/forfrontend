import React, { useState } from "react";
import { FcFlashOn } from "react-icons/fc";
import { FaCaretDown } from "react-icons/fa";
import { Ri24HoursLine } from "react-icons/ri";
import FindDoctor from "./FindDoctor";

const FindDoctorInfo = () => (
  <div></div>
);

const FindHospitalInfo = () => (
  <div>
  </div>
);

const VideoConsultInfo = () => (
  <div>
  </div>
);

const MedicinesInfo = () => (
  <div>
  </div>
);

const Header = () => {
  const [activeTab, setActiveTab] = useState("findDoctor");
  const [showLogin, setShowLogin] = useState(false);


  const renderTabContent = () => {
    switch (activeTab) {
      case "findDoctor":
        return <FindDoctorInfo />;
      case "findHospital":
        return <FindHospitalInfo />;
      case "videoConsult":
        return <VideoConsultInfo />;
      case "medicines":
        return <MedicinesInfo />;
      default:
        return null;
    }
  };

  const handleEmergencyCall = () => {
    alert("Emergency call initiated!");
  };
   
  const handleLoginSignupClick = () => {
    setShowLogin(true);
  };

  

  return (
    <>
      
      <header className="d-flex flex-column align-items-center">
        <div
          className="px-3 py-2 text-bg-White border-bottom"
          style={{ borderBottom: "4px solid", width: "100%" }}
        >
          <div className="container">
            <div className="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
              <a
                href="/"
                className="d-flex align-items-center my-2 my-lg-0 me-lg-auto text-white textDecoration-none"
              >
                <svg
                  className="bi me-2"
                  width="40"
                  height="32"
                  role="img"
                  aria-label="Bootstrap"
                >
                  <use xlinkHref="#bootstrap"></use>
                </svg>
              </a>
              <header className="d-flex justify-content-center py-3">
                <a href="#" className="nav-link">
                  <img
                    src="logo.png"
                    alt="Medicare Logo"
                    width="55"
                    height="55"
                    className="me-2"
                  />
                </a>
                <a href="#" className="nav-link">
                  <h2>Medicare</h2>
                </a>
              </header>

              <ul className="nav col-12 col-lg-auto my-2 justify-content-center my-md-0 text-small">
              <li className="nav-item">
  <a
    href="#"
    className={`nav-link ${
      activeTab === "pincode" ? "active" : ""
    } d-flex align-items-center`}
  >
    <FcFlashOn size={40} />
    <div className="ml-2">
      <h5 className="mb-0" style={{ color: "black" }}>
        Enter Your Pincode
      </h5>
      <span className="text-muted d-none d-lg-inline">421204 Mumbai</span>
      <FaCaretDown size={30} />
    </div>
  </a>
</li>

                <li className="nav-item">
  <form
    className="col-12 col-lg-auto mb-3 mb-lg-0 d-flex align-items-center"
    role="search"
  >
    <div className="input-group">
      <input
        type="search"
        className="form-control"
        placeholder="Search doctors, clinics, hospital, etc"
        aria-label="Search"
      />
      <button className="btn btn-outline-secondary" type="button">
        Search
      </button>
    </div>
  </form>
</li>
                <li className="nav-item">
                <a
                href="#"
                className={`nav-link ${
                  activeTab === "emergency" ? "active" : ""
                } d-flex align-items-center`}
                onClick={handleEmergencyCall}
              >
                <Ri24HoursLine size={35} />
                <div className="ml-2">
                  <h5 className="mb-0" style={{ color: "red" }}>
                    Emergency Call
                  </h5>
                  <span className="text-muted">1800-111-555</span>
                </div>
              </a>
                </li>
              </ul>

             
              <div className="text-center text-lg-end col-12 col-lg-auto">
  <button
    type="button"
    className="btn btn-light text-dark me-2"
    onClick={handleLoginSignupClick}
  >
    Login/Signup
  </button>
</div>


            </div>
          </div>
        </div>
        <div
          style={{
            borderBottom: ".25px solid",
            width: "100%",
            backgroundColor: "#f8f8f8",
          }}>
        </div>
      </header>

      <div
        className="px-3 py-2 border-bottom mb-3"
        style={{
          borderBottom: "4px solid",
          width: "100%",
          backgroundColor: "#f8f8f8",
        }}
      >
        <div className="container d-flex flex-wrap justify-content-center">
          <header className="d-flex justify-content-center py-0">
            <ul className="nav nav-pills">
              <li className="nav-item">
                <a
                  href="#"
                  className={`nav-link ${
                    activeTab === "findDoctor" ? "active" : ""
                  }`}
                  onClick={() => setActiveTab("findDoctor")}
                >
                  Find Doctor
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="#"
                  className={`nav-link ${
                    activeTab === "findHospital" ? "active" : ""
                  }`}
                  onClick={() => setActiveTab("findHospital")}
                >
                  Find Hospital
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="#"
                  className={`nav-link ${
                    activeTab === "videoConsult" ? "active" : ""
                  }`}
                  onClick={() => setActiveTab("videoConsult")}
                >
                  Video Consult
                </a>
              </li>
              <li className="nav-item">
                <a
                  href="#"
                  className={`nav-link ${
                    activeTab === "medicines" ? "active" : ""
                  }`}
                  onClick={() => setActiveTab("medicines")}
                >
                  Medicines
                </a>
              </li>
            </ul>
          </header>
          {activeTab === "FindDoctor" && <FindDoctor/>}
        </div>
      </div>
      <div className="container">{renderTabContent()}</div>
    </>
  );
};

export default Header;
