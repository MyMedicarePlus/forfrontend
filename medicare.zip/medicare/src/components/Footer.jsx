import React ,{useState}from 'react';

const Footer = () => {
  const [activeTab, setActiveTab] = useState("find-doctor");

  return (
    <>
    <div className="container" style={{ backgroundColor: "#28328C"}}>
      <footer className="d-flex flex-column align-items-center" >
        <ul className="nav justify-content-center border-top pb-3 mb-3" style={{width: "100%"}}> 
          <li className="nav-item me-0">
            <a href="#" className="nav-link">
              <img src="logo.png" alt="Medicare Logo" width="50" height="55" className="me-0" />
            </a>
          </li>
          <li className="nav-item mb-0">
            <a href="#" className="nav-link"><h5  style={{ color: "white" }}>Medicare-Plus</h5></a>
          </li>
        </ul>
        <div className="container col mb-4">
          <p  style={{ color: "white" }}>Medicare-Plus,We take the guesswork out of finding the best doctors,hospitals and care facilities.We want to make healthcare easier and more transparent, if you or a loved one has an illness and injury that requries medical attention,it can be confusing to work through all your options.That's why we created DocIndia: a platform that educate and empowers patients to make the right decision based on credentials,reviews and other credible information. </p>
        </div>
        
        <div className="container"  >
          <div className="row" >
            <div className="col mb-3" >
              <h5 style={{ color: "white" }}>For Patients</h5>
              <ul className="nav flex-column" >
                <li className="nav-item mb-2" >
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                    <h6 style={{ color: "white" }}>Find Doctors</h6></a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                    <h6 style={{ color: "white" }}>All Cities</h6></a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#"
                   className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                   
                 >
                    <h6 style={{ color: "white" }}>Patients Q&A</h6></a>
                </li>
              </ul>
            </div>

            <div className="col mb-3">
              <h5 style={{ color: "white" }}>Useful Links</h5>
              <ul className="nav flex-column">
                <li className="nav-item mb-2">
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                    <h6 style={{ color: "white" }}>Home</h6></a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                  <h6 style={{ color: "white" }}>FAQ's</h6></a>
                </li>
                <li className="nav-item mb-2">
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                    <h6 style={{ color: "white" }}>Contact Us</h6></a>
                </li>
              </ul>
            </div>

            <div className="col mb-3">
              <h5 style={{ color: "white" }}>For Doctors</h5>
              <ul className="nav flex-column">
                <li className="nav-item mb-2">
                  <a href="#" 
                  className={`nav-link p-0 text-body-secondary ${activeTab === 'find-doctors' ? 'active' : ''}`}
                  
                >
                    <h6 style={{ color: "white" }}>Claim Your Profile</h6></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top" style={{color: "white", width: '100%'}}>
           <p> 2024 Medicare-plus.All right reserved</p>
           <p>Terms and conditions  . policy</p>
          
        </div>
      </footer>
    </div>
    </>
  );
};



export default Footer;
