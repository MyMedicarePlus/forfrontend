import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './components/Header';
import Content from './components/Content';
import Footer from './components/Footer';
import MainContent from './components/MainContent';
import { useState } from 'react';

function App() {
  const[selectedTab,setSelectedTab] = useState("Find Doctor")
 
  return (
    <>
   
      <div className='content'>
      <Header></Header>
      <Content></Content>
      <MainContent></MainContent>
      <Footer></Footer>
      </div>
    
    </>
  )
}

export default App
